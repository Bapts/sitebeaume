<?php

// Define your backend username and password here
$username = "admin"; 
$password = "123"; 

?>